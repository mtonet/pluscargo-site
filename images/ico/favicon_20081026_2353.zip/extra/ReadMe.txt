
* The favicon

  favicon.ico  --  The favicon file (supports both 16*16 and 32*32 dimensions).

    You can add a favicon to your web page by uploading favicon.ico to your
    website and inserting the following HTML tag inside the <head> ... </head>
    section of your web page.

      <link rel="shortcut icon" href="favicon.ico" >

    If you would like to test the favicon after updating your web page, the
    Favicon Validator can check the favicon files and tags on your website.

      http://www.htmlkit.com/go/favicon/validator/


* Other extra files in this package

  The following files are included for your convenience. You don't have to
  upload or do anything else with these optional files.

    preview_16x16.png  --  16*16 PNG image file of the favicon.
    ReadMe.txt  --  This quick reference.


* More information

  If you have any questions, more information and tech support is available at:

    http://www.htmlkit.com/go/favicon/help/


  Thank you for using FavIcon from Pics.
